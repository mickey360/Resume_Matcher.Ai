# Deployment guide

## 1. GitHub

Create one repository and push the entire project:

```text
ai-resume-matcher/
  frontend/
  backend/
  docs/
```

## 2. Render backend

Create a Web Service from the GitHub repository.

Settings:

- Root Directory: `backend`
- Runtime: Python 3
- Build Command: `pip install -r requirements.txt`
- Start Command: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`

Environment:

```text
ENABLE_SEMANTIC_MODEL=true
SEMANTIC_MODEL=all-MiniLM-L6-v2
ALLOWED_ORIGINS=https://YOUR-VERCEL-DOMAIN.vercel.app
```

Deploy. Test:

```text
https://YOUR-RENDER-DOMAIN.onrender.com/health
```

Expected:

```json
{"status":"ok","service":"ai-resume-matcher-api"}
```

## 3. Vercel frontend

Import the same GitHub repository.

Settings:

- Root Directory: `frontend`
- Build Command: `npm run build`

Environment:

```text
NEXT_PUBLIC_API_URL=https://YOUR-RENDER-DOMAIN.onrender.com
```

Deploy.

## 4. Final CORS update

Once you know the final Vercel domain, update Render:

```text
ALLOWED_ORIGINS=https://your-project.vercel.app
```

If you use a custom domain, include both origins separated by commas.

## 5. GitHub changes

You don't upload separately to Vercel or Render.

Push changes to GitHub:

```bash
git add .
git commit -m "Update resume matcher"
git push
```

Vercel redeploys the frontend when frontend files change, and Render redeploys the backend when backend files change.
